<?php
$pg = $_GET['pg'];
include("connection.php");
if($pg == 3 and $_SERVER['REQUEST_METHOD'] == 'POST'){
        // Email address verification, do not edit.
        $link="https://noraktech.com";
        $firstname =mysqli_real_escape_string($db, $_POST['name']);
        $email =mysqli_real_escape_string($db, $_POST['email']);
        $phone =mysqli_real_escape_string($db, $_POST['phone']);
        $comments = mysqli_real_escape_string($db, $_POST['message']);
        $to = "info@noraktech.com";
              
        if($phone != ''){
            $name.= " (".$phone.")";
        }
			
    
    //begin of HTML message
    $message = <<<EOF
					
					<html>
					<head>
					<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
					<title>Contact Us</title>
					</head>
					<body bgcolor="#e5e5e5">
					<h1>From $fistname</h1>
					<table width="945" border="0" align="center" cellpadding="0" cellspacing="0">
						  <tr>
                              <td valign="top">
                             From $email,  $phone <br>
								message: $comments
								<br><br>
								<a href="$link" target ="_blank">Access Webmail</a>	
							</td>
						  </tr>
						
						</table>

					</body>
					</html>

EOF;
   //end of message
   
   $headers = "MIME-Version: 1.0\r\n";  
   $headers .= "Content-type: text/html\r\n";
   $headers  .= "From: $email\r\n";
   mail($to, $email, $message, $headers);
       
	if(mail($to, $email, $message, $headers)) {
        // Email has sent successfully, echo a success page.
        mysqli_query($db, "insert into contact SET name = '$firstname', email = '$email', phone = '$phone', message='$comments' ") or die(mysqli_error($db));        
		$sql = "Your message has been submitted to us. You will be contacted soon";
		echo "
            <script language='javascript'>
            alert('Your message has been submitted to us. You will be contacted soon');
                location.href='index'
            </script>
		";
	}
}

if($pg == 3 and $_SERVER['REQUEST_METHOD'] == 'POST' and isset($_POST['erpsubmit'])){

	$link="https://noraktech.com";
        $to = "info@noraktech.com";
		$erpName = mysqli_real_escape_string($connect, $_POST['erpName']);
        $erpEmail = mysqli_real_escape_string($connect, $_POST['erpEmail']);
    
    	$insert_query = "INSERT INTO freetrial(company_name,email) VALUES ('$erpName','$erpEmail')";
	mysqli_query($db,$insert_query);  
	$sql = "Your message has been submitted to us. You will be contacted soon";
			
			echo "
					<script language='javascript'>
					alert('Your message has been submitted to us. You will be contacted soon');
							location.href='index'
					</script>
	";

   
    //begin of HTML message
    $erpmessage = <<<EOF
					
					<html>
					<head>
					<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
					<title>NORAKLE PAYROLL FREE TRIAL REQUEST</title>
					</head>
					<body bgcolor="#e5e5e5">
					<h1>From $erpName</h1>
					<table width="945" border="0" align="center" cellpadding="0" cellspacing="0">
						  <tr>
                                <td valign="top">
                                <h1> 
                                <b>From:</b>  $erpEmail <br><br>
                                </h1>
                                <br><br>
                                <b>Full-name:</b>  $erpName
                                <br><br>
                                <h1>request for free trial or wants to get started with norakle erp</h1> 

							</td>
						  </tr>
						
						</table>

					</body>
					</html>

EOF;
	 //end of message
	
   
   $headers = "MIME-Version: 1.0\r\n";  
   $headers .= "Content-type: text/html\r\n";
   $headers  .= "From: $email\r\n";
	 mail($to, $erpEmail, $erpmessage, $headers);
	

	if(mail($to, $erpEmail, $erpmessage, $headers)){
	$insert_query = "INSERT INTO freetrial(company_name,email) VALUES ('$erpName','$erpEmail')";
	mysqli_query($db,$insert_query);  
	$sql = "Your message has been submitted to us. You will be contacted soon";
			
			echo "
					<script language='javascript'>
					alert('Your message has been submitted to us. You will be contacted soon');
							location.href='index'
					</script>
	";

	}
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Payroll Mangement System</title>
	<link rel="icon" href="img/logo.png" type="image/logo.png">

  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
  <link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="css/style2.css">

<!--  <link rel="stylesheet" href="css/style.css">-->
</head>
<body>
  <!--================Header Menu Area =================-->
  <header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container box_1620">
          <!-- Brand and toggle get grouped for better mobile display -->
          <a class="navbar-brand logo_h" href="index.html"><img src="img/logo.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
            <ul class="nav navbar-nav menu_nav justify-content-end">
              <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li> 
              <li class="nav-item"><a class="nav-link" href="#features">Feature</a></li> 
              <li class="nav-item"><a class="nav-link" href="#pricing">Price</a>
             
              <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
            </ul>

            <ul class="navbar-right">
              <li class="nav-item">
                <input type="submit" class="button button-header bg" value="Start Your Free Trial" data-toggle="modal" data-target="#formModal">
              </li>
            </ul>
          </div> 
        </div>
      </nav>
    </div>
  </header>
  <!--================Header Menu Area =================-->


  <main class="side-main">
    <!--================ Hero sm Banner start =================-->      
    <section class="hero-banner">
      <div class="container">
        <div class="row top">
          <div class="col-lg-7">
            <div class="hero-banner__img">
              <img class="img-fluid" src="img/banner/hero-banner.png" alt="">
            </div>
          </div>
          <div class="col-lg-5 pt-1">
            <div class="hero-banner__content">
              <h1>Norakle Payroll Software</h1>
              <p class="text-white" style="font-size:18px;">Flexible and Powerful Software Designed to Meet Your Need, Save Time and Reduce Cost</p>
              <input type="submit" class="button bg" href="#" data-toggle="modal" data-target="#formModal" value="Start Your Free Trial">
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--================ Hero sm Banner end =================-->
<div class="modal" id="formModal">
        <div class="modal-dialog">
        <div class="modal-content">
            
            <div class="modal-header">
            <h2 class="modal-title">Get Started</h2>
                <button class="close" data-dismiss="modal">
                <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form action="?pg=3" method="post" id="reused_form">
                <div class="form-group">
                <label for="name">Business Name</label>
                    <input type="text" class="form-control" name="erpName">
                </div>
                 <div class="form-group">
                <label for="email">Email</label>
                    <input type="email" class="form-control" name="erpEmail">
                </div>
                <div class="modal-footer">
                <input type="submit" class="btn btn-primary btn-block" value="Submit" name="erpSubmit">
                </div>
                
                </form>
            </div>
                
            
            </div>
        
        </div>
    
    </div>
    
    
<!--------------    Aside start-------------------------->

    <!--================ Feature section start =================-->      
    <section class="section-margin">
      <div class="container">
        <div class="section-intro pb-85px text-center">
          <h2 class="section-intro__title text-theme">ROBUST CLOUD-BASED PAYROLL SOFTWARE</h2>
          <p class="section-intro__subtitle">Norakle Payroll is all that you need to administer payroll seamlessly for your organization. With features that allow you to structure your payroll process to suit your organization, you can’t get overworked or out of options.</p>
        </div>

        <div class="container">
          <div class="row">
            <div class="col-lg-4">
              <div class="card card-feature text-center text-lg-left mb-4 mb-lg-0 pb-4">
                <span class="card-feature__icon">
                  <i class="ti-package"></i>
                </span>
                <h3 class="card-feature__title">24/7 Expert Support</h3>
                <p class="card-feature__subtitle">Enjoy simplified payroll process with our free uninterrupted support to help you through any difficult process.</p>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card card-feature text-center text-lg-left mb-4 mb-lg-0">
                <span class="card-feature__icon">
                  <i class="ti-fullscreen"></i>
                </span>
                <h3 class="card-feature__title">Flexible Salary Disbursement</h3>
                <p class="card-feature__subtitle">Enhance the disbursement of salaries through our system’s easy generation of handwritten or printable paycheques.</p>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card card-feature text-center text-lg-left mb-4 mb-lg-0">
                <span class="card-feature__icon">
                  <i class="ti-layers"></i>
                </span>
                <h3 class="card-feature__title">Employee Portal Access</h3>
                <p class="card-feature__subtitle">Allow employee secured online accessibility to their paystubs, pay history and payroll information</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--================ Feature section end =================-->      
    
    <!--================ about section start =================--> 
      <section class="section-padding--small my-5">
      <div class="container">
       <h2 class="pb-5 text-theme">More Features That Gives You A Better Organizational Structure</h2>
        <div class="row align-items-center">
          <div class="col-md-5 mb-5 mb-md-0">
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                    <p>Web-based and Mobile-friendly Application</p>
                </div>
            </div>
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                    <p>User-friendly Interfaces</p>
                </div>
            </div>
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                    <p>Reconciliation Tools</p>
                </div>
            </div>
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                    <p>Automated Inputs</p>
                </div>
            </div>
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                    <p>Payroll Checklist</p>
                </div>
            </div>
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                   <p>Customized Payslips</p>
                   
                </div>
            </div>
            <div class="d-flex">
                <div class="self-align-start px-3">
                    <i class="fa fa-check"></i>
                </div>
                <div class="self-align-end">
                   <p>Complete Statutory Compliance (deductions for WHT, PIT, SST etc.)</p>  
                </div>
            </div>
          </div>
          <div class="col-md-7">
            <div class="abt-img">
              <img class="img-fluid" src="img/screen/payroll-dashboard.png" alt="">
            </div>
          </div>
        </div>
      </div>
    </section>      
   
    <!--================ about section end =================-->      
    
    <!--================ features start =================-->      
    <section class="section-margin">
      <div class="container-fluid">
       <h2 class="text-theme section-intro__title text-center px-5 pt-5" id="features">PAYROLL STRUCTURE THAT HANDLES ANY KIND OF PAYMENT STRUCTURE</h2>
        <div class="section-intro pb-85px text-center">
          <p class="section-intro__subtitle">The integrated features in our stress-free solution is everything you need to manage and organize your payroll process.</p>
        </div>

        <div class="row mx-5">
          <div class="col-lg-8">

            <div class="row offer-single-wrapper">
              <div class="col-lg-4 offer-single">
                <div class="card offer-single__content text-left">
                  <span class="offer-single__icon">
                    <i class="ti-pencil-alt"></i>
                  </span>
                  <h4>Finish Pay Runs in a click</h4>
                  <p>Payday can be really stressful, however, our system helps to simplify this process. You spend less time and achieve more with just a click, after setting up your paydays and schedule.</p>
                </div>
              </div>
              <div class="col-lg-4 offer-wrapper">
                <div class="card offer-single__content text-left pb-6">
                  <span class="offer-single__icon">
                    <i class="ti-lock"></i>
                  </span>
                  <h4>Share Secured Payslips Online</h4>
                  <p>Easily generate password-protected payslips that can be accessed either online and downloaded in PDF formats.</p>
                </div>
              </div>
              
              <div class="col-lg-4  col-sm-4 col-md-6 col-xs-6 offer-wrapper">
                <div class="card offer-single__content text-left pb-9">
                  <span class="offer-single__icon">
                    <i class="ti-ruler-pencil"></i>
                  </span>
                  <h4>Disburse Salaries Online</h4>
                  <p>Make employees’ happier by making payments promptly through paycheques or cash.</p>
                </div>
              </div>

            </div>
            

            <div class="row offer-single-wrapper">
 <div class="col-lg-4 offer-wrapper">
                <div class="card offer-single__content text-left pb-3">
                  <span class="offer-single__icon">
                    <i class="ti-light-bulb"></i>
                  </span>
                  <h4>Get Up-to-date Notifications</h4>
                  <p>Be in charge of your payroll operations. Norakle payroll helps you be in the know about your confirmed payroll process, upcoming tax submission dates, scheduled salary increment dates.</p>
                </div>
              </div>
             
              <div class="col-lg-4 offer-wrapper">
                <div class="card offer-single__content text-left">
                  <span class="offer-single__icon">
                    <i class="ti-pencil-alt"></i>
                  </span>
                  <h4>Apply Custom Deductions to Payslips</h4>
                  <p>Manage employees’ voluntary and mandatory payroll deductions including the application of pre-tax and post-tax deductions, and additions which include bonuses, commissions and more</p>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4 col-md-6 col-xs-6 offer-wrapper">
                <div class="card offer-single__content text-left">
                  <span class="offer-single__icon">
                    <i class="ti-pencil-alt"></i>
                  </span>
                  <h4>Automate Loan Management</h4>
                  <p>Improve the management of loans taken by employees through automated tracking of loans and periodical deductions of loan instalments from employees’ pay.</p>
                </div>
              </div>
            </div>

          </div>
          <div class="col-lg-4">
            <div class="offer-single__img">
              <img class="img-fluid pr-5 w-200" src="img/screen/salary-variation.png" alt="">
            </div>
          </div>
             
        </div>
      </div>
    </section>
    <!--================  end =================-->  
    <!--================ Start Clients Logo Area =================-->
     <section class="clients_logo_area section-padding">
      <div class="container-fluid">
        <h2 class="text-theme section-intro__title2 text-left pl-3 pb-3">SOME OF OUR PAYROLL<br> APPLICATION SCREENSHOTS</h2>
        <div class="clients_slider owl-carousel">
          <div class="item">
            <img src="img/screenshots/payroll-dashboard.png" class="img-fluid" alt="">
          </div>
          <div class="item">
            <img src="img/screenshots/payroll-salary-variation.png" class="img-fluid" alt="">
          </div>
          <div class="item">
            <img src="img/screenshots/payroll.png" class="img-fluid" alt="">
          </div>
          <div class="item">
            <img src="img/screenshots/payroll-bank-menu.png" class="img-fluid" alt="">
          </div>
          <div class="item">
            <img src="img/screenshots/payroll-payment.png" class="img-fluid" alt="">
          </div>
        </div>
      </div>
    </section> 
    <!--================ End Clients Logo Area =================-->    

   <section class="section-padding--small mb-4">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-5 mb-5 mb-md-0">
            <div class="about__content">
              <h2 class="text-theme">Want to Get Started?</h2>
              <p>Have no worries about your data migration. We offer efficient 24/7 support in helping you get your new payroll system up and running in no time. And if you choose to do it yourself, our customized template helps you import new and existing employee and required organization details effortlessly.</p>
              <input type="submit" class="btn btn-primary" data-toggle="modal" data-target="#formModal" value="Take a Free Trial">
             
            </div>
          </div>
          <div class="col-md-7">
            <div class="abt-img">
              <img class="img-fluid" src="img/screen/paroll-management-system.png" alt="">
            </div>
          </div>
        </div>
      </div>
    </section>
   
   

    <!--================ Pricing section start =================-->  
     <section class="pricing-table mb-5">
        <div class="container">
            <div class="block-heading" id="pricing">
              <h2>NORAKLE PAYROLL PRICING</h2>
              
            </div>
            <div class="row justify-content-md-center">
                <div class="col-md-5 col-lg-4">
                    <div class="item">
                        <div class="ribbon">Start-up</div>
                        <div class="heading">
                            <h3>START-UP</h3>
                        </div>
                        <p>-Flat Monthly fee</p>
                         <p>-2 Users Plus Accountant</p>
                        <div class="features">
                            <h4><span class="feature">Full Support</span> : <span class="value">Yes</span></h4>
                            <h4><span class="feature">Duration</span> : <span class="value">Monthly</span></h4>
                           
                        </div>
                        <div class="price">
                            <h4>&#8358;6,000</h4>
                        </div>
                        <button class="btn btn-block btn-outline-primary" type="submit" data-toggle="modal" data-target="#formModal">BUY NOW</button>
                    </div>
                </div>
                <div class="col-md-5 col-lg-4">
                    <div class="item">
                       
                        <div class="heading">
                            <h3>MEDIUM</h3>
                        </div>
                        <p>-Monthly Fee</p>
                        <p>-For Team Up To 10 Users</p>
                        <div class="features">
                            <h4><span class="feature">Full Support</span> : <span class="value">Yes</span></h4>
                            <h4><span class="feature">Duration</span> : <span class="value">Monthly</span></h4>
                           
                        </div>
                        <div class="price">
                            <h4>&#8358;4,000</h4>
                        </div>
                        <button class="btn btn-block btn-outline-primary" type="submit" data-toggle="modal" data-target="#formModal">BUY NOW</button>
                    </div>
                </div>
                <div class="col-md-5 col-lg-4">
                    <div class="item">
                        <div class="ribbon">Best Value</div>
                        <div class="heading">
                            <h3>ENTERPRISES</h3>
                        </div>
                        <p>Per User</p>
                        <p>Per Monthly</p>
                        <div class="features">
                            <h4><span class="feature">Full Support</span> : <span class="value">Yes</span></h4>
                            <h4><span class="feature">Duration</span> : <span class="value">Monthly</span></h4>
                           
                        </div>
                        <div class="price">
                            <h4>&#8358;2,000</h4>
                        </div>
                        <button class="btn btn-block btn-outline-primary" type="submit" data-toggle="modal" data-target="#formModal">BUY NOW</button>
                    </div>
                </div>
                
            </div>
        </div>
    </section>

   
    
    <!--================ Pricing section end =================-->      

    <!--================ Testimonial section start =================-->      
    <!-- <section class="section-padding bg-magnolia">
      <div class="container">
        <div class="section-intro pb-5 text-center">
          <h2 class="section-intro__title">Client Says Me</h2>
          <p class="section-intro__subtitle">Vel aliquam quis, nulla pede mi commodo tristique nam hac. Luctus torquent velit felis commodo pellentesque nulla cras. Tincidunt hacvel alivquam </p>
        </div>

        <div class="owl-carousel owl-theme testimonial">
          <div class="testimonial__item text-center">
            <div class="testimonial__img">
              <img src="img/testimonial/testimonial1.png" alt="">
            </div>
            <div class="testimonial__content">
              <h3>Stephen Mcmilan</h3>
              <p>Executive, ACI Group</p>
              <p class="testimonial__i">Also made from. Give may saying meat there from heaven it lights face had is gathered god earth light for life may itself shall whales made they're blessed whales also made from give may saying meat. There from heaven it lights face had also made from. Give may saying meat there from heaven</p>
            </div>
          </div>
          <div class="testimonial__item text-center">
            <div class="testimonial__img">
              <img src="img/testimonial/testimonial1.png" alt="">
            </div>
            <div class="testimonial__content">
              <h3>Stephen Mcmilan</h3>
              <p>Executive, ACI Group</p>
              <p class="testimonial__i">Also made from. Give may saying meat there from heaven it lights face had is gathered god earth light for life may itself shall whales made they're blessed whales also made from give may saying meat. There from heaven it lights face had also made from. Give may saying meat there from heaven</p>
            </div>
          </div>
          <div class="testimonial__item text-center">
            <div class="testimonial__img">
              <img src="img/testimonial/testimonial1.png" alt="">
            </div>
            <div class="testimonial__content">
              <h3>Stephen Mcmilan</h3>
              <p>Executive, ACI Group</p>
              <p class="testimonial__i">Also made from. Give may saying meat there from heaven it lights face had is gathered god earth light for life may itself shall whales made they're blessed whales also made from give may saying meat. There from heaven it lights face had also made from. Give may saying meat there from heaven</p>
            </div>
          </div>
        </div>
      </div>
    </section> -->
    <!--================ Testimonial section end =================-->      

    
    <div class="container-fluid"> 
  <div class="footer" id="contact">
        <div class="row">
            
            <div class="col-sm-6 txt">
               <h2 class="text-white p-5">Get In Touch with US</h2>
               <div class="text-white pl-5" style=" text-align: justify;">
                           
                        
                            <span style="text-align:justify;">8 Alhaja Oluwakemi Street,
                            Anthony Village,<br> Lagos State,
                            Nigeria.</span>
                        <br><br>
                        <i class="fa fa-phone"></i> 
                                 (+234) 806 243 9476, (+234) 906 607 3086
                                 <br><br>        
                        <div style="display: flex; padding: 2px; text-align: justify;">
                            <i style="margin-top: 7px;" class="fa fa-envelope-o"></i> 
                            <a style="margin-left: 4px;" href="mailto:info@noraktech.com">info@noraktech.com</a>, <br>
                             
                        </div>
                        <a href="mailto:support@noraktech.com"> support@noraktech.com</a><br>
                        <i class="fa fa-clock-o"></i> 
                        Monday - Friday: 8:00 AM to 5:00 PM<br>
                </div> 
                
            </div>
            <div class="col-sm-6 for p-4">
               <form action="?pg=3" method="post" class="bg-white py-4 px-5" id="reused_form">
                 <h2 class="form-title">Contact Us</h2>
                  <div class="input-group  mb-3">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fa fa-user"></i></span>
                      </div>
                      <input type="text" name="name" placeholder="Full Name" class="form-control">
                  </div>
                  <div class="input-group  mb-3">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                      </div>
                      <input type="email" name="email" class="form-control" placeholder="Email">
                  </div>
                  <div class="input-group mb-3">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fa fa-phone"></i></span>
                      </div>
                          <input type="text" name="phone" class="form-control" placeholder="Phone Number">
                  </div>
                  <div class="input-group  mb-3">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fa fa-edit"></i></span>
                      </div>
                      <textarea name="message" class="form-control" rows="1" placeholder="Message"></textarea>
                  </div>
                  <input type="submit" class="btn btn-primary btn-block" name="submit" value="Send" id="btnContactUs">
               </form> 
            </div>
        </div>
        
    </div>
    </div>

    
  </main>
  <footer class="bg-theme">
         
            
                <div class="container" style="padding:20px;">
                   <div class="row">
                   
                    <div class=" col-lg-12 text-center pt-3">
                        <p class="copyright">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved <a href="https://noraktech.com" target="_blank" style="color: white;">| Norak Technologies Limited</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
      </div>
        </footer>
  
  


  <!-- ================ start footer Area ================= -->
  <!-- <footer class="footer-area section-gap">
		<div class="container">
			<div class="row">
				<div class="col-xl-2 col-sm-6 mb-4 mb-xl-0 single-footer-widget">
					<h4>Top Products</h4>
					<ul>
						<li><a href="#">Managed Website</a></li>
						<li><a href="#">Manage Reputation</a></li>
						<li><a href="#">Power Tools</a></li>
						<li><a href="#">Marketing Service</a></li>
					</ul>
				</div>
				<div class="col-xl-2 col-sm-6 mb-4 mb-xl-0 single-footer-widget">
					<h4>Quick Links</h4>
					<ul>
						<li><a href="#">Jobs</a></li>
						<li><a href="#">Brand Assets</a></li>
						<li><a href="#">Investor Relations</a></li>
						<li><a href="#">Terms of Service</a></li>
					</ul>
				</div>
				<div class="col-xl-2 col-sm-6 mb-4 mb-xl-0 single-footer-widget">
					<h4>Features</h4>
					<ul>
						<li><a href="#">Jobs</a></li>
						<li><a href="#">Brand Assets</a></li>
						<li><a href="#">Investor Relations</a></li>
						<li><a href="#">Terms of Service</a></li>
					</ul>
				</div>
				<div class="col-xl-2 col-sm-6 mb-4 mb-xl-0 single-footer-widget">
					<h4>Resources</h4>
					<ul>
						<li><a href="#">Guides</a></li>
						<li><a href="#">Research</a></li>
						<li><a href="#">Experts</a></li>
						<li><a href="#">Agencies</a></li>
					</ul>
				</div>
				<div class="col-xl-4 col-md-8 mb-4 mb-xl-0 single-footer-widget">
					<h4>Newsletter</h4>
					<p>You can trust us. we only send promo offers,</p>
					<div class="form-wrap" id="mc_embed_signup">
						<form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
						 method="get" class="form-inline">
							<input class="form-control" name="EMAIL" placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '"
							 required="" type="email">
							<button class="click-btn btn btn-default">subscribe</button>
							<div style="position: absolute; left: -5000px;">
								<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
							</div>

							<div class="info"></div>
						</form>
					</div>
				</div>
			</div>
			<div class="footer-bottom row align-items-center text-center text-lg-left">
				<p class="footer-text m-0 col-lg-8 col-md-12">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
 Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. </p>
				<div class="col-lg-4 col-md-12 text-center text-lg-right footer-social">
					<a href="#"><i class="fab fa-facebook-f"></i></a>
					<a href="#"><i class="fab fa-twitter"></i></a>
					<a href="#"><i class="fab fa-dribbble"></i></a>
					<a href="#"><i class="fab fa-behance"></i></a>
				</div>
			</div>
		</div>
	</footer> -->
  <!-- ================ End footer Area ================= -->

  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="js/jquery.ajaxchimp.min.js"></script>
  <script src="js/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>