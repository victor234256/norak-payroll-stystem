<?php
session_start();
	date_default_timezone_set('Africa/Lagos');
	$db = mysqli_connect("localhost", "root", "", "norakle");
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	
?>